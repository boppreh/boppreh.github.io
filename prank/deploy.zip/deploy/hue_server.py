from simpleserver import blocking_serve
from os import system

def speak(text):
    system('~/.hue/deploy/espeak "{}"'.format(text))

blocking_serve(speak, port=9238)